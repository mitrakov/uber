# example

A usage example of flutter_typeahead

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
