## [0.2.2] - 10-06-2020
FIxed issues with incorrect key being passed as travelmode
Changed waypoint documentation
## [0.2.1] - 05-04-2020.
Breaking change, the response object has been refined to a more
suitable object that contains the status of the api and the error message.
## [0.2.0] - 05-04-2020.
Add travel mode,
Fixed unhandled error exception.
## [0.1.0] - 25-04-2019.
update readme.
## [0.0.1] - 25-04-2019.
initial release.
