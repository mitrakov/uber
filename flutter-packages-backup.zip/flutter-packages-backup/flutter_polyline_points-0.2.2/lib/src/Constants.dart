/// description: 
/// project: flutter_polyline_points
/// @package: 
/// @author: dammyololade
/// created on: 05/04/2020
class Constants {

  static const String API_KEY = "AIzaSyB5Tl3ge9gMZ8pOcwPWlSBliJamOCtQch0";
}