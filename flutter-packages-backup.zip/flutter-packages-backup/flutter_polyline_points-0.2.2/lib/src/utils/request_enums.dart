/// description:
/// project: flutter_polyline_points
/// @package:
/// @author: dammyololade
/// created on: 12/05/2020
enum TravelMode { driving, bicycling, transit, walking }