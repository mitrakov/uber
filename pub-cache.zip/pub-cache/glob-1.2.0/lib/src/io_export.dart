// Copyright (c) 2019, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

/// This library exists only to satisfy build_runner, which doesn't allow
/// sdk libraries to be conditional imported or exported directly.
library glob.src.io_export;

export 'dart:io';
