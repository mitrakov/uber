## 0.1.1+2

- Support the latest version of `package:json_annotation`.
- Require Dart 2.2 or later.

## 0.1.1+1

- Support the latest version of `package:json_annotation`.

## 0.1.1

- Add JSON serialization

## 0.1.0

- Initial release
